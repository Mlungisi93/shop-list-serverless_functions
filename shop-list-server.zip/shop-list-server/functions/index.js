/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

const {onRequest} = require("firebase-functions/v2/https");
const logger = require("firebase-functions/logger");
const functions = require("firebase-functions");
const cors = require('cors')({ origin: true });
const admin = require('firebase-admin');

const serviceAccount = require('./config/serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://shop-list-6651b-default-rtdb.firebaseio.com/",
});

const database = admin.database().ref('/items');

// Create and deploy your first functions
// https://firebase.google.com/docs/functions/get-started

// exports.helloWorld = onRequest((request, response) => {
//   logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });

//refactor
const getItemsFromDatabase = (res) => {
    let items = [];
  
    return database.on('value', (snapshot) => {
      snapshot.forEach((item) => {
        items.push({
          id: item.key,
          item: item.val().item
        });
      });   
      res.status(200).json(items);
    }, (error) => {
      res.status(500).json({
        message: `Something went wrong. ${error}`
      })
    })
  };

exports.helloWorld = functions.https.onRequest((req, res) => {
    res.send("Hello from a Serverless Database!");
  });

  exports.addItem = functions.https.onRequest((req, res) => {
    return cors(req, res, () => {
      if(req.method !== 'POST') {
        return res.status(401).json({
          message: 'Not allowed'
        })
      }
      console.log(req.body)
    
      const item = req.body.item
  
      database.push({ item });
  
      getItemsFromDatabase(res);
    })
  });

  exports.getItems = functions.https.onRequest((req, res) => {
    return cors(req, res, () => {
      if(req.method !== 'GET') {
        return res.status(404).json({
          message: 'Not allowed'
        })
      }

      getItemsFromDatabase(res);
    })
  });

  exports.delete = functions.https.onRequest((req, res) => {
    return cors(req, res, () => {
      if(req.method !== 'DELETE') {
        return res.status(401).json({
          message: 'Not allowed'
        })
      }
      const id = req.query.id
      admin.database().ref(`/items/${id}`).remove()
      getItemsFromDatabase(res)
    })
  });

exports.updateItem = functions.https.onRequest((req, res) => {
  return cors(req, res, () => {
    if (req.method !== 'PUT') {
      return res.status(401).json({
        message: 'Not allowed'
      });
    }
    console.log(req.body);

    const itemId = req.body.id;
    const updatedItem = req.body.item;

    if (!itemId || !updatedItem) {
      return res.status(400).json({
        message: 'Invalid request'
      });
    }

    const itemRef = admin.database().ref(`/items/${itemId}`);
    itemRef.update({ item: updatedItem });
    getItemsFromDatabase(res);
      // .then(() => {
      //   return res.status(200).json({
      //     message: 'Item updated successfully'
      //   });
      // })
      // .catch((error) => {
      //   return res.status(500).json({
      //     message: 'Error updating item',
      //     error: error.message
      //   });
      // });
  });
});